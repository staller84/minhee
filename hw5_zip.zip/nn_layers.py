import numpy as np
from skimage.util.shape import view_as_windows


class nn_convolutional_layer:

    def __init__(self, Wx_size, Wy_size, input_size, in_ch_size, out_ch_size, std=1e0):

        # Xavier init
        self.W = np.random.normal(0, std / np.sqrt(in_ch_size * Wx_size * Wy_size / 2),
                                  (out_ch_size, in_ch_size, Wx_size, Wy_size))
        self.b = 0.01 + np.zeros((1, out_ch_size, 1, 1))
        self.input_size = input_size

    def update_weights(self, dW, db):
        self.W += dW
        self.b += db

    def get_weights(self):
        return self.W, self.b

    def set_weights(self, W, b):
        self.W = W
        self.b = b

    def forward(self, x):
        ##########
        ##########
        #   Complete the method with your implementation
        ##########
        ##########

        return out

    def backprop(self, x, dLdy):

        ##########
        ##########
        #   Complete the method with your implementation
        ##########
        ##########
        return dLdx, dLdW, dLdb


class nn_max_pooling_layer:
    def __init__(self, stride, pool_size):
        self.stride = stride
        self.pool_size = pool_size

    def forward(self, x):
        ##########
        ##########
        #   Complete the method with your implementation
        ##########
        ##########

        return out

    def backprop(self, x, dLdy):
        ##########
        ##########
        #   Complete the method with your implementation
        ##########
        ##########

        return dLdx

class nn_activation_layer:

    # linear layer. creates matrix W and bias b
    # W is in by out, and b is out by 1
    def __init__(self):
        pass

    def forward(self, x):
        return np.maximum(x, 0)

    def backprop(self, x, dLdy):
        return (x >= 0).astype('uint8') * dLdy


# fully connected layer
class nn_fc_layer:

    def __init__(self, input_size, output_size, filt_size=1, std=1):
        # Xavier-He init
        self.W = np.random.normal(0, std/np.sqrt(input_size*filt_size**2/2), (output_size, input_size, filt_size, filt_size))
        self.b=0.01+np.zeros((1,output_size,1,1))

    def forward(self,x):
        # compute forward pass of given parameter
        output_size = self.W.shape[0]
        batch_size = x.shape[0]
        Wx = np.dot(x.reshape((batch_size, -1)),(self.W.reshape(output_size, -1)).T)
        return np.expand_dims(np.expand_dims(Wx,axis=2),axis=3)+self.b

    def backprop(self,x,dLdy):

        dLy = np.expand_dims(dLdy,axis=4)
        dyx = np.expand_dims(self.W,axis=0)

        dLdx = np.sum(dLy*dyx,axis=1).reshape(x.shape)

        dLdW=np.expand_dims(x,axis=1)*dLy
        dLdW=np.sum(dLdW,axis=0)

        dLdb=dLdy*np.ones(dLdy.shape)
        dLdb=(np.sum(dLdb,axis=0,keepdims=True))

        return dLdx,dLdW,dLdb

    def update_weights(self,dLdW,dLdb):

        # parameter update
        self.W=self.W+dLdW
        self.b=self.b+dLdb

    def get_weights(self):
        return self.W, self.b

    def set_weights(self, W, b):
        self.W = W
        self.b = b


class nn_softmax_layer:

    def __init__(self):
        pass

    def forward(self, x):
        s = x - np.amax(x, axis=1)[:, np.newaxis]
        return (np.exp(s) / np.sum(np.exp(s), axis=1)[:, np.newaxis]).reshape((x.shape[0],x.shape[1]))

    def backprop(self, x, dLdy):
        # getting input dLdy of dimension n x len(x)
        # should return dLdx

        p = self.forward(x)
        dLdx = -np.sum(p * dLdy, axis=1, keepdims=True) * p + p * dLdy

        return dLdx.reshape(x.shape)


class nn_cross_entropy_layer:

    def __init__(self):
        self.eps=1e-15

    def forward(self, x, y):

        batch_size = y.shape[0]
        num_class = x.shape[1]
        onehot = np.zeros((batch_size, num_class))
        onehot[range(batch_size), (np.array(y)).reshape(-1, )] = 1

        # to avoid numerial instability
        x[x<self.eps]=self.eps
        x=x/np.sum(x,axis=1)[:,np.newaxis]

        return sum(-np.sum(np.log(np.array(x).reshape(batch_size, -1)) * onehot, axis=0)) / batch_size

    def backprop(self, x, y):
        batch_size = x.shape[0]
        p = np.zeros(x.shape)
        p[range(batch_size), y.reshape((batch_size,))] = -1 / x[range(batch_size), y.reshape((batch_size,))]

        return p / batch_size
